window.onload = function() {
	var lblle = document.getElementsByClassName("lb1le")[0];
	var lb1ri = document.getElementsByClassName("lb1ri")[0];
	var lb1list = document.getElementsByClassName("lb1");
	var i = 0;
	var dian = 0;
	var isclick = true;
	//	console.log(lb1list.length)

	lblle.onclick = function() {
		if (isclick) {
			isclick = false
			if (i == 0) {
				i = 7
			}
			i--
			//			console.log(i)
			for (var a = 0; a < lb1list.length; a++) {
				lb1list[a].classList.remove("on1");
			}
			lb1list[i].classList.add("on1")
			setTimeout(function() {
				isclick = true
			}, 1000)
		}

	}

	lb1ri.onclick = function() {
		if (isclick) {
			isclick = false
			i++
			if (i == 7) {
				i = 0
			}

			//			console.log(i)
			for (var a = 0; a < lb1list.length; a++) {
				lb1list[a].classList.remove("on1");
			}
			lb1list[i].classList.add("on1")
			setTimeout(function() {
				isclick = true
			}, 1000)
		}

	}

	timer = setInterval(lblle.onclick, 3000);

	function anim() {
		clearInterval(timer)
		var timer = setInterval(function() {
			if (i == 6) {
				i = 0;
			} else {
				i++
			}
			for (var b = 0; b < lb1list.length; b++) {
				lb1list[b].classList.remove("on1")
			}
			lb1list[i].classList.add("on1")
			console.log(i)
		}, 3000)

	}
	///---------------------------------------------------------/
	var xuangxk = document.getElementsByClassName("xuangxk")[0];
	var xxkimg = xuangxk.getElementsByTagName("img");
	var jule = document.getElementsByClassName("jule")[0];
	var juri = document.getElementsByClassName("juri")[0];
	var x = 0;
	jule.onclick = function() {
		leon(xxkimg, xxkimg.length, "on1")
	}
	juri.onclick = function() {
		rion(xxkimg,xxkimg.length,"on1")
	}
	function leon(name, m, active) {
		if (x == 0) {
			x = m
		}
		x--
		for (var b = 0; b < name.length; b++) {
			name[b].classList.remove(active);
		}
		name[x].classList.add(active);
				console.log(x)
	}

	function rion(name, m, active) {
		if (x == m-1) {
			x = 0;
		} else {
			x++
		}
		for (var b = 0; b < name.length; b++) {
			name[b].classList.remove(active);
		}
		name[x].classList.add(active);
				console.log(x)
	}

}